/*
 * InnoCode client-site tracking + support chat integration.
 * Add this module to the customer-facing website (the site at innocoderyjwnr.vercel.app).
 * Use startInnoTracking({ name, phone }) after the customer profile is known.
 */
import { initializeApp, getApps } from 'firebase/app';
import { getAuth, signInAnonymously } from 'firebase/auth';
import {
  getFirestore, doc, collection, getDoc, setDoc, updateDoc, addDoc,
  serverTimestamp, onSnapshot, query, orderBy
} from 'firebase/firestore';

const firebaseConfig = {
  apiKey: 'AIzaSyBeD62DbxPGb5NBI1r7NYCqMTXJkWVfN4E',
  authDomain: 'innocode-b499c.firebaseapp.com',
  projectId: 'innocode-b499c',
  storageBucket: 'innocode-b499c.firebasestorage.app',
  messagingSenderId: '1020343040309',
  appId: '1:1020343040309:web:0e4d769c4aaeefcefbf47c'
};

const firebaseApp = getApps().find(item => item.options.projectId === firebaseConfig.projectId)
  || initializeApp(firebaseConfig, 'innoCodeTracking');
const auth = getAuth(firebaseApp);
const db = getFirestore(firebaseApp);
let userPromise = null;
let currentSession = null;
let heartbeat = null;
let profile = { name: '', phone: '' };
let endHandlerAdded = false;

async function ensureCustomerUser() {
  if (auth.currentUser) return auth.currentUser;
  if (!userPromise) userPromise = signInAnonymously(auth).then(result => result.user).finally(() => { userPromise = null; });
  return userPromise;
}

export async function registerInnoCustomer({ name = '', phone = '' } = {}) {
  profile = { name: String(name).trim(), phone: String(phone).trim() };
  const user = await ensureCustomerUser();
  const ref = doc(db, 'customers', user.uid);
  const snap = await getDoc(ref);
  const data = { uid: user.uid, name: profile.name, phone: profile.phone, updatedAt: serverTimestamp(), lastSeenAt: serverTimestamp() };
  if (!snap.exists()) data.createdAt = serverTimestamp();
  await setDoc(ref, data, { merge: true });
  if (currentSession) await updateDoc(currentSession, { name: profile.name, phone: profile.phone });
  return user.uid;
}

export async function startInnoTracking({ name = '', phone = '' } = {}) {
  await registerInnoCustomer({ name, phone });
  const user = auth.currentUser;
  const sessionRef = doc(collection(db, 'sessions'));
  currentSession = sessionRef;
  await setDoc(sessionRef, {
    uid: user.uid,
    name: profile.name,
    phone: profile.phone,
    startedAt: serverTimestamp(),
    lastSeenAt: serverTimestamp(),
    endedAt: null,
    status: 'active',
    page: window.location.pathname,
    userAgent: navigator.userAgent.slice(0, 300)
  });

  if (heartbeat) clearInterval(heartbeat);
  heartbeat = setInterval(async () => {
    if (!currentSession) return;
    try {
      await updateDoc(currentSession, { lastSeenAt: serverTimestamp() });
      await updateDoc(doc(db, 'customers', user.uid), { lastSeenAt: serverTimestamp(), updatedAt: serverTimestamp() });
    } catch (error) {
      console.warn('[InnoCode tracking] heartbeat failed:', error);
    }
  }, 30000);

  if (!endHandlerAdded) {
    window.addEventListener('pagehide', endInnoTracking, { once: true });
    endHandlerAdded = true;
  }
  return user.uid;
}

export async function endInnoTracking() {
  if (heartbeat) { clearInterval(heartbeat); heartbeat = null; }
  if (!currentSession) return;
  const ref = currentSession;
  currentSession = null;
  try {
    await updateDoc(ref, { endedAt: serverTimestamp(), lastSeenAt: serverTimestamp(), status: 'ended' });
  } catch (error) {
    // A browser may terminate before a final network write completes.
    console.warn('[InnoCode tracking] session-end write was not confirmed:', error);
  }
}

export async function sendInnoSupportMessage(message) {
  const text = String(message || '').trim();
  if (!text) throw new Error('اكتب رسالة أولاً.');
  if (text.length > 2000) throw new Error('الرسالة أطول من الحد المسموح (2000 حرف).');
  const user = await ensureCustomerUser();
  const chatRef = doc(db, 'chats', user.uid);
  const chatSnap = await getDoc(chatRef);
  const chatData = {
    uid: user.uid,
    name: profile.name,
    phone: profile.phone,
    lastMessage: text,
    updatedAt: serverTimestamp()
  };
  if (!chatSnap.exists()) chatData.createdAt = serverTimestamp();
  await setDoc(chatRef, chatData, { merge: true });
  await addDoc(collection(db, 'chats', user.uid, 'messages'), {
    sender: 'customer', text, createdAt: serverTimestamp(), seen: false
  });
}

// Call this from the existing support-chat UI to display replies sent by the admin.
export async function listenInnoSupportReplies(callback) {
  const user = await ensureCustomerUser();
  const messagesQuery = query(collection(db, 'chats', user.uid, 'messages'), orderBy('createdAt', 'asc'));
  return onSnapshot(messagesQuery, snapshot => {
    const replies = snapshot.docs
      .map(item => ({ id: item.id, ...item.data() }))
      .filter(item => item.sender === 'admin');
    callback(replies);
  }, error => console.error('[InnoCode support] could not load replies:', error));
}
